
//-----------------------REGISTERING THE APPLICATION AND DEPENDENCIES------

var clothingHome = angular.module("ClothingHome", [ "ngRoute","ngCookies" ]);
var clothingApp = angular.module("ClothingApp", [ "ngRoute" ,"ngCookies"]);
var productApp = angular.module("ProductApp", [ "ngRoute" ,"ngCookies"]);

// ----------------------CONFIGURING THE APPLICATION------------------------

clothingHome.config(function($routeProvider) {
	$routeProvider.when('/shop', {
		templateUrl : 'shop.html'			
	}).otherwise({
		redirectTo : '/'
	});
});



// --------------------------------------------------------------------------

var URI = getURI();

// ---------------------------------------------------------------------

productApp.filter('GenderFilter', function() {

	return function(value) {
		var split1=value.split(";");
		split2=split1[0].split(":");
		return split2[1];
	};

});

productApp.filter('TypeFilter', function() {

	return function(value) {
		var split1=value.split(";");
		split2=split1[1].split(":");
		return split2[1];
	};

});

productApp.filter('SizeFilter', function() {

	return function(value) {
		var split1=value.split(";");
		split2=split1[2].split(":");
		return split2[1];
	};

});


