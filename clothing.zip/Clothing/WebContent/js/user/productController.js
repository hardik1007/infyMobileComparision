productApp.controller('productController', function($scope, $http,
		$cookies) {
	
	$scope.product={};
	$scope.product.id=$cookies.get("id");
	$scope.product.image=$cookies.get("image");
	$scope.product.name=$cookies.get("name");
	$scope.product.brand=$cookies.get("brand");
	$scope.product.quantity=$cookies.get("quantity");
	$scope.product.discount=$cookies.get("discount");
	$scope.product.sellingPrice=$cookies.get("sellingPrice");
	$scope.product.specification=$cookies.get("specification");
	$scope.username = $cookies.get("userName");
	$scope.searchText = "";
	$scope.flag=0;
	$scope.search=function()
	{
		$scope.flag=0;
		$cookies.put("flag",$scope.flag);
		$cookies.put("searchText",$scope.searchText);
		window.location="clothingHome.html";
	};
	
	if($scope.username==null){
		window.location="../index.html";
	}
	$scope.message=null;
	$scope.returnList=null;
	$scope.suggestedproduct=function(){
		$http.get(URI+"Clothing/"+$scope.product.id).then(
				function(response) {
					$scope.returnList=response.data;
					if($scope.returnList.length==0){
						$scope.message = "No Suggestions for this Product";
					}
				},
				function(response) {
					$scope.returnList=null;
					$scope.message = "Connection Error! Unable to fetch data!";
				});
		
		
		
	}
	$scope.home=function(){
		window.location="clothingHome.html"
	};
	$scope.productPage=function(item){
		$cookies.put("id",item.productId);
		$cookies.put("image",item.image);
		$cookies.put("name",item.name);
		$cookies.put("brand",item.brand);
		$cookies.put("quantity",item.quantity);
		$cookies.put("sellingPrice",item.sellingPrice);
		$cookies.put("discount",item.discount);
		$cookies.put("specification",item.specification);
		
		window.location="shop.html";
	};
	
	$scope.logout = function() {

		$cookies.remove('userName');

		window.location = "../index.html";

	};

	
	
});