clothingHome.controller('clothingHomeController', function($scope, $http,$cookies) {
	$scope.searchFlag=1;
	$scope.searchText = "";
	$scope.searchFlag=$cookies.get("flag");
	if($scope.searchFlag==0){
		$scope.searchText=$cookies.get("searchText");
		$scope.searchFlag=1;
		$cookies.remove("flag");
	}
	
	$scope.sort="false";
	$scope.choosenView = null;
	$scope.choosenCategory = null;
	$scope.productList = [];
	$scope.allClothesList = [];
	$scope.returnList = [];
	$scope.brands = [];
	$scope.categories = [];
	$scope.types = [];
	$scope.sizes = [];
	$scope.filter = {};
	$scope.filter.flag = null;
	$scope.filter.selectBrands = [];
	$scope.filter.selectCategories = [];
	$scope.filter.minPrice = 0;
	$scope.filter.maxPrice = 99999;
	$scope.filter.selectSizes = [];
	$scope.filter.selectTypes = [];
	$scope.filteredClothes = [];
	$scope.allBrands=[];
	$scope.allTypes=[];
	$scope.allCategories=[];
	$scope.allSizes=[];
	$scope.brandCount=[];
	$scope.categoryCount=[];
	$scope.sizeCount=[];
	$scope.typeCount=[];
	$scope.brandButton=true;
	$scope.categoryButton=true;
	$scope.typeButton=true;
	$scope.sizeButton=true;
	$scope.clearAllButton = null;

	$scope.username = $cookies.get("userName");
	if($scope.username==null){
		window.location="../index.html";
	}
	$scope.init_page = function() {
		$http.get(URI + "Clothing/allProductsList").then(function(response) {
			$scope.returnList = response.data;
			for (index in $scope.returnList) {
				if ($scope.returnList[index].category === "CLOTHING") {
					$scope.productList.push($scope.returnList[index]);
				}
			}
		
			$scope.allClothesList = $scope.productList;
			// brands
			var flag = 0;
			for (i in $scope.productList) {
				flag = 0;
				for (j in $scope.brands) {
					if ($scope.productList[i].brand == $scope.brands[j]) {
						flag = 1;
						break;
					}
				}
				if (flag == 0) {
					$scope.brands.push($scope.productList[i].brand);
				}
			}
			$scope.allBrands=$scope.brands;
			// categories
			flag = 0;
			for (i in $scope.productList) {
				flag = 0;
				temp = $scope.productList[i].name;
				temp = temp.split(" ");
				temp = temp[temp.length - 1];
				for (j in $scope.categories) {
					if (temp == $scope.categories[j]) {
						flag = 1;
						break;
					}
				}
				if (flag == 0) {
					$scope.categories.push(temp);
				}
			}
			$scope.allCategories=$scope.categories;
			// type
			flag = 0;
			for (i in $scope.productList) {
				flag = 0;
				temp = $scope.productList[i].specification;
				temp = temp.split(";");
				temp = temp[1].split(":");
				for (j in $scope.types) {
					if (temp[1] == $scope.types[j]) {
						flag = 1;
						break;
					}
				}
				if (flag == 0) {
					$scope.types.push(temp[1]);
				}
			}
			$scope.allTypes=$scope.types;
			// sizes
			flag = 0;
			for (i in $scope.productList) {
				flag = 0;
				temp = $scope.productList[i].specification;
				temp = temp.split(";");
				temp = temp[2].split(":");
				for (j in $scope.sizes) {
					
					if (temp[1] == $scope.sizes[j]) {
						flag = 1;
						break;
					}
				}
				if (flag == 0) {
					$scope.sizes.push(temp[1]);
				}
			}
			$scope.allSizes=$scope.sizes;
			$scope.setCount();
			$scope.message = null;

		}, function(response) {
			$scope.message = response.data.message;
			$scope.productList = null;
		});

	};
	//dynamic category dropdown generation for brands
	$scope.changeCategoriesForBrand = function() {
		fl=0
		for (k in $scope.filter.selectBrands){
		if($scope.filter.selectBrands[k]!=null){
			fl=1;
		}
		}
		if(fl==0){
			$scope.categories=$scope.allCategories;
			
			return;
			
		}
		flag = 0;
		$scope.categories=[];
	
		for (i in $scope.productList) {
			flag1=0;
			for (j in $scope.filter.selectBrands) {
				if ($scope.productList[i].brand == $scope.filter.selectBrands[j]) {
					flag1 = 1;
				
					break;
				}
			}
			if (flag1 == 1) {
				flag = 0;
				temp = $scope.productList[i].name;
				temp = temp.split(" ");
				temp = temp[temp.length - 1];
				for (j in $scope.categories) {
					
					if ( temp== $scope.categories[j]) {
						flag = 1;
						break;
					}
				}
				if (flag == 0) {
					$scope.categories.push(temp);
				}
			}
		}
			
		};
		//dynamic types dropdown generation for brands
		$scope.changeTypesForBrand = function() {
			fl=0
			for (k in $scope.filter.selectBrands){
			if($scope.filter.selectBrands[k]!=null){
				fl=1;
			}
			}
			if(fl==0){
				$scope.types=$scope.allTypes;
		
				
				return;
				
			}
			flag = 0;
			$scope.types=[];
		
			for (i in $scope.productList) {
				flag1=0;
				for (j in $scope.filter.selectBrands) {
					if ($scope.productList[i].brand == $scope.filter.selectBrands[j]) {
						flag1 = 1;
					
						break;
					}
				}
				if (flag1 == 1) {
					flag = 0;
					temp = $scope.productList[i].specification;
					temp = temp.split(";");
					temp = temp[1].split(":");
					for (j in $scope.types) {
						
						if ( temp[1]== $scope.types[j]) {
							flag = 1;
							break;
						}
					}
					if (flag == 0) {
						$scope.types.push(temp[1]);
					}
				}
			}
				
			};
			//dynamic sizes dropdown generation for brands
			$scope.changeSizesForBrand = function() {
				fl=0
				for (k in $scope.filter.selectBrands){
				if($scope.filter.selectBrands[k]!=null){
					fl=1;
				}
				}
				if(fl==0){
					$scope.sizes=$scope.allSizes;
					
					return;
					
				}
				flag = 0;
				$scope.sizes=[];
			
				for (i in $scope.productList) {
					flag1=0;
					for (j in $scope.filter.selectBrands) {
						if ($scope.productList[i].brand == $scope.filter.selectBrands[j]) {
							flag1 = 1;
						
							break;
						}
					}
					if (flag1 == 1) {
						flag = 0;
						temp = $scope.productList[i].specification;
						temp = temp.split(";");
						temp = temp[2].split(":");
						for (j in $scope.sizes) {
							
							if ( temp[1]== $scope.sizes[j]) {
								flag = 1;
								break;
							}
						}
						if (flag == 0) {
							$scope.sizes.push(temp[1]);
						}
					}
				}
					
				};
//dynamic types dropdown generation for category change
$scope.changeTypesForCategory = function() {
	fl=0
	for (k in $scope.filter.selectCategories){
	if($scope.filter.selectCategories[k]!=null){
		fl=1;
	}
	}
	if(fl==0){
		$scope.types=$scope.allTypes;
	
		
		return;
		
	}
	flag = 0;
	$scope.types=[];
	for (i in $scope.productList) {
		temp = $scope.productList[i].name;
		temp = temp.split(" ");
		temp = temp[temp.length - 1];
		flag1 = 0;
		for (j in $scope.filter.selectCategories) {
			if (temp == $scope.filter.selectCategories[j]) {
				flag1 = 1;
				break;
			}
		}
		if (flag1 == 1) {
			flag = 0;
			temp = $scope.productList[i].specification;
			temp = temp.split(";");
			temp = temp[1].split(":");
			for (j in $scope.types) {
				if (temp[1] == $scope.types[j]) {
					flag = 1;
					break;
				}
			}
			if (flag == 0) {
				$scope.types.push(temp[1]);
			}
		}
	}
		
	};
	//dynamic Brands dropdown generation for category
	$scope.changeBrandsForCategory = function() {
		fl=0
		for (k in $scope.filter.selectCategories){
		if($scope.filter.selectCategories[k]!=null){
			fl=1;
		}
		}
		if(fl==0){
			$scope.brands=$scope.allBrands;
		
			
			return;
			
		}
		flag = 0;
		$scope.brands=[];
	
		for (i in $scope.productList) {
			temp = $scope.productList[i].name;
			temp = temp.split(" ");
			temp = temp[temp.length - 1];
			flag1 = 0;
			for (j in $scope.filter.selectCategories) {
				if (temp == $scope.filter.selectCategories[j]) {
					flag1 = 1;
				
					break;
				}
			}
			if (flag1 == 1) {
				flag = 0;
				for (j in $scope.brands) {
					if ( $scope.productList[i].brand== $scope.brands[j]) {
						flag = 1;
						break;
					}
				}
				if (flag == 0) {
					$scope.brands.push($scope.productList[i].brand);
				}
			}
		}
			
		};
		
		//dynamic Size dropdown generation for category
		$scope.changeSizeForCategory = function() {
			fl=0
			for (k in $scope.filter.selectCategories){
			if($scope.filter.selectCategories[k]!=null){
				fl=1;
			}
			}
			if(fl==0){
				$scope.sizes=$scope.allSizes;
		
			
				return;
				
			}
			flag = 0;
			$scope.sizes=[];
			for (i in $scope.productList) {
				temp = $scope.productList[i].name;
				temp = temp.split(" ");
				temp = temp[temp.length - 1];
				flag1 = 0;
				for (j in $scope.filter.selectCategories) {
					if (temp == $scope.filter.selectCategories[j]) {
						flag1 = 1
						break;
					}
				}
				if (flag1 == 1) {
					flag = 0;
					temp = $scope.productList[i].specification;
					temp = temp.split(";");
					temp = temp[2].split(":");
					for (j in $scope.sizes) {
						if ( temp[1]== $scope.sizes[j]) {
							flag = 1;
							break;
						}
					}
					if (flag == 0) {
						$scope.sizes.push(temp[1]);
					}
				}
			}
				
			};
			
			//dynamic category dropdown generation for sizes changed
			$scope.changeCategoriesForSize = function() {
				fl=0
				for (k in $scope.filter.selectSizes){
				if($scope.filter.selectSizes[k]!=null){
					fl=1;
				}
				}
				if(fl==0){
					$scope.categories=$scope.allCategories;
			
					return;
					
				}
				flag = 0;
				$scope.categories=[];
			
				for (i in $scope.productList) {
					flag1=0;
					temp = $scope.productList[i].specification;
					temp = temp.split(";");
					temp = temp[2].split(":");
					for (j in $scope.filter.selectSizes) {
						
						if (temp[1] == $scope.filter.selectSizes[j]) {
							flag1 = 1;
						
							break;
						}
					}
					if (flag1 == 1) {
						flag = 0;
						temp = $scope.productList[i].name;
						temp = temp.split(" ");
						temp = temp[temp.length - 1];
						for (j in $scope.categories) {
							
							if ( temp== $scope.categories[j]) {
								flag = 1;
								break;
							}
						}
						if (flag == 0) {
							$scope.categories.push(temp);
						}
					}
				}
					
				};
				
				//dynamic brand dropdown generation for sizes changed
			$scope.changeBrandForSize = function() {
					fl=0
					for (k in $scope.filter.selectSizes){
					if($scope.filter.selectSizes[k]!=null){
						fl=1;
					}
					}
					if(fl==0){
						$scope.brands=$scope.allBrands;
					
						return;
						
					}
					flag = 0;
					$scope.brands=[];
				
					for (i in $scope.productList) {
						flag1=0;
						temp = $scope.productList[i].specification;
						temp = temp.split(";");
						temp = temp[2].split(":");
						for (j in $scope.filter.selectSizes) {
							
							if (temp[1] == $scope.filter.selectSizes[j]) {
								flag1 = 1;
							
								break;
							}
						}
						if (flag1 == 1) {
							flag = 0;
							for (j in $scope.brands) {
								
								if ( $scope.productList[i].brand== $scope.brands[j]) {
									flag = 1;
									break;
								}
							}
							if (flag == 0) {
								$scope.brands.push($scope.productList[i].brand);
							}
						}
					}
						
					};
					
					//dynamic type dropdown generation for sizes changed
					$scope.changetypeForSize = function() {
						fl=0
						for (k in $scope.filter.selectSizes){
						if($scope.filter.selectSizes[k]!=null){
							fl=1;
						}
						}
						if(fl==0){
							$scope.types=$scope.allTypes;
						
							return;
							
						}
						flag = 0;
						$scope.types=[];
					
						for (i in $scope.productList) {
							flag1=0;
							temp = $scope.productList[i].specification;
							temp = temp.split(";");
							temp = temp[2].split(":");
							for (j in $scope.filter.selectSizes) {
								
								if (temp[1] == $scope.filter.selectSizes[j]) {
									flag1 = 1;
								
									break;
								}
							}
							if (flag1 == 1) {
								flag = 0;
								temp = $scope.productList[i].specification;
								temp = temp.split(";");
								temp = temp[1].split(":");
								for (j in $scope.types) {
									
									if ( temp[1]== $scope.types[j]) {
										flag = 1;
										break;
									}
								}
								if (flag == 0) {
									$scope.types.push(temp[1]);
								}
							}
						}
							
						};
						
						//dynamic brand dropdown generation for type changed
						$scope.changeBrandForType = function() {
								fl=0
								for (k in $scope.filter.selectTypes){
								if($scope.filter.selectTypes[k]!=null){
									fl=1;
								}
								}
								if(fl==0){
									$scope.brands=$scope.allBrands;
								
									return;
									
								}
								flag = 0;
								$scope.brands=[];
							
								for (i in $scope.productList) {
									flag1=0;
									temp = $scope.productList[i].specification;
									temp = temp.split(";");
									temp = temp[1].split(":");
									for (j in $scope.filter.selectTypes) {
										
										if (temp[1] == $scope.filter.selectTypes[j]) {
											flag1 = 1;
										
											break;
										}
									}
									if (flag1 == 1) {
										flag = 0;
										for (j in $scope.brands) {
											
											if ( $scope.productList[i].brand== $scope.brands[j]) {
												flag = 1;
												break;
											}
										}
										if (flag == 0) {
											$scope.brands.push($scope.productList[i].brand);
										}
									}
								}
									
								};
								
								//dynamic category dropdown generation for types changed
								$scope.changeCategoriesForType = function() {
									fl=0
									for (k in $scope.filter.selectTypes){
									if($scope.filter.selectTypes[k]!=null){
										fl=1;
									}
									}
									if(fl==0){
										$scope.categories=$scope.allCategories;
							
										return;
										
									}
									flag = 0;
									$scope.categories=[];
								
									for (i in $scope.productList) {
										flag1=0;
										temp = $scope.productList[i].specification;
										temp = temp.split(";");
										temp = temp[1].split(":");
										for (j in $scope.filter.selectTypes) {
											
											if (temp[1] == $scope.filter.selectTypes[j]) {
												flag1 = 1;
											
												break;
											}
										}
										if (flag1 == 1) {
											flag = 0;
											temp = $scope.productList[i].name;
											temp = temp.split(" ");
											temp = temp[temp.length - 1];
											for (j in $scope.categories) {
												
												if ( temp== $scope.categories[j]) {
													flag = 1;
													break;
												}
											}
											if (flag == 0) {
												$scope.categories.push(temp);
											}
										}
									}
										
									};
									
									
									//dynamic Size dropdown generation for types
									$scope.changeSizeForType = function() {
										fl=0
										for (k in $scope.filter.selectTypes){
										if($scope.filter.selectTypes[k]!=null){
											fl=1;
										}
										}
										if(fl==0){
											$scope.sizes=$scope.allSizes;
									
											return;
											
										}
										flag = 0;
										$scope.sizes=[];
										for (i in $scope.productList) {
											temp = $scope.productList[i].specification;
											temp = temp.split(";");
											temp = temp[1].split(":");
											flag1 = 0;
											for (j in $scope.filter.selectTypes) {
												if (temp[1] == $scope.filter.selectTypes[j]) {
													flag1 = 1
													break;
												}
											}
											if (flag1 == 1) {
												flag = 0;
												temp = $scope.productList[i].specification;
												temp = temp.split(";");
												temp = temp[2].split(":");
												for (j in $scope.sizes) {
													if ( temp[1]== $scope.sizes[j]) {
														flag = 1;
														break;
													}
												}
												if (flag == 0) {
													$scope.sizes.push(temp[1]);
												}
											}
										}
											
										};

	$scope.all = function() {
		$scope.productList = $scope.allClothesList;
	};
	$scope.men = function() {
		$scope.tempList = [];
		for (i in $scope.productList) {
			temp = $scope.productList[i].specification;
			temp = temp.split(";");
			temp = temp[0].split(":");
			if (temp[1] == "MEN") {
				$scope.tempList.push($scope.productList[i]);
			}

		}

		$scope.productList = $scope.tempList;
	};
	$scope.women = function() {
		$scope.tempList = [];
		for (i in $scope.productList) {
			temp = $scope.productList[i].specification;
			temp = temp.split(";");
			temp = temp[0].split(":");
			if (temp[1] == "WOMEN") {
				$scope.tempList.push($scope.productList[i]);
			}

		}

		$scope.productList = $scope.tempList;
	};


	$scope.filterAll = function() {
		
		$scope.filteredClothes = [];
		fl=0
		for (k in $scope.filter.selectBrands){
		if($scope.filter.selectBrands[k]!=null){
			fl+=1;
		}
		}
		for (k in $scope.filter.selectCategories){
			if($scope.filter.selectCategories[k]!=null){
				fl+=1;
			}
			}
		for (k in $scope.filter.selectTypes){
			if($scope.filter.selectTypes[k]!=null){
				fl+=1;
			}
			}
		for (k in $scope.filter.selectSizes){
			if($scope.filter.selectSizes[k]!=null){
				fl+=1;
			}
			}
		if(fl==0){
			$scope.productList=$scope.allClothesList;
			return;
			
		}
		$scope.tempList=$scope.allClothesList;
		//filter on brands
		filterApplied=0;
		for (i in $scope.tempList){
			flag=0;
			for( j in $scope.filter.selectBrands){
				if($scope.tempList[i].brand==$scope.filter.selectBrands[j]){
					flag=1;
					break;
				}
			}
			if(flag==1){
				filterApplied=1;
				$scope.filteredClothes.push($scope.tempList[i]);
			}
		}
		if(filterApplied==0) $scope.tempList=$scope.allClothesList;
		else {$scope.tempList=$scope.filteredClothes;	
		$scope.filteredClothes=[];}
		//filter on categories
		for (i in $scope.tempList){
			flag=0;
			temp = $scope.tempList[i].name;
			temp = temp.split(" ");
			temp = temp[temp.length - 1];
			for( j in $scope.filter.selectCategories){
				if(temp==$scope.filter.selectCategories[j]){
					flag=1;
					break;
				}
			}
			if(flag==1){
				filterApplied=2;
				$scope.filteredClothes.push($scope.tempList[i]);
			}
		}
		
		if(filterApplied==0)$scope.tempList=$scope.allClothesList;
		else if(filterApplied==2){$scope.tempList=$scope.filteredClothes;
		$scope.filteredClothes = [];}
		
			
		
		//filter on sizes
		for (i in $scope.tempList){
			flag=0;
			temp = $scope.tempList[i].specification;
			temp = temp.split(";");
			temp = temp[2].split(":");
			for( j in $scope.filter.selectSizes){
				if(temp[1]==$scope.filter.selectSizes[j]){
					flag=1;
					break;
				}
			}
			if(flag==1){
				filterApplied=3;
				$scope.filteredClothes.push($scope.tempList[i]);
			}
		}
		if(filterApplied==0)$scope.tempList=$scope.allClothesList;
		else if(filterApplied==3){$scope.tempList=$scope.filteredClothes;
		$scope.filteredClothes = [];}
	
		
		//filter on type
		for (i in $scope.tempList){
			flag=0;
			temp = $scope.tempList[i].specification;
			temp = temp.split(";");
			temp = temp[1].split(":");
			for( j in $scope.filter.selectTypes){
				if(temp[1]==$scope.filter.selectTypes[j]){
					flag=1;
					break;
				}
			}
			if(flag==1){
				filterApplied=4;
				$scope.filteredClothes.push($scope.tempList[i]);
			}
		}
		
		if(filterApplied==0)$scope.tempList=$scope.allClothesList;
		else if(filterApplied==4){$scope.tempList=$scope.filteredClothes;
		$scope.filteredClothes = [];}
	 $scope.productList=$scope.tempList;
		
		
		
	};
	

	$scope.brandFunction = function() {
		$scope.brandButton=false;
		$scope.setCount();
		$scope.clearAllButton = true;
	};

	// Reset Price
	$scope.priceFunction = function() {
		$scope.clearAllButton = true;
	};
	$scope.categoryFunction = function() {
		$scope.categoryButton=false;
		$scope.setCount();
		$scope.clearAllButton = true;
	};
	$scope.sizeFunction=function(){
		$scope.sizeButton=false;
		$scope.setCount();
		$scope.clearAllButton = true;
	};

	// Clear Price to be changed
	$scope.clearPrice = function() {
		$scope.clothing.price = null;
		for ( var i in $scope.clothing.price) {
			$scope.clothing.price[i] = "false";
		}
		$scope.clearPriceButton = false;
		//$scope.filterAll();

	};

	$scope.typeFunction = function() {
		$scope.typeButton=false;
		$scope.setCount();
		$scope.clearAllButton = true;
	};

	$scope.clearAll = function() {
		for ( var i in $scope.filter.selectBrands) {
			$scope.filter.selectBrands[i] = null;
		}
		for ( var i in $scope.filter.selectTypes) {
			$scope.filter.selectTypes[i] = null;
		}
		for ( var i in $scope.filter.selectCategories) {
			$scope.filter.selectCategories[i] = null;
		}
		for ( var i in $scope.filter.selectTypes) {
			$scope.filter.selectTypes[i] = null;
		}
		$scope.clearAllButton = false;
		$scope.types=$scope.allTypes;
		$scope.brands=$scope.allBrands;
		$scope.sizes=$scope.allSizes;
		$scope.productList=$scope.allClothesList;
		$scope.categories=$scope.allCategories;
		$scope.setCount();
		$scope.filter.minPrice=0;
		$scope.filter.maxPrice=0;
		//$scope.filterAll();
	};
	$scope.setSort=function(val){
		if(val==0){
			$scope.sort="-sellingPrice";
		}
		else{
			$scope.sort="sellingPrice";
		}
	};
	
	$scope.setCount=function(){
		
		
		fl=0
		for (k in $scope.filter.selectBrands){
		if($scope.filter.selectBrands[k]!=null){
			fl+=1;
		}
		}
		for (k in $scope.filter.selectCategories){
			if($scope.filter.selectCategories[k]!=null){
				fl+=1;
			}
			}
		for (k in $scope.filter.selectTypes){
			if($scope.filter.selectTypes[k]!=null){
				fl+=1;
			}
			}
		for (k in $scope.filter.selectSizes){
			if($scope.filter.selectSizes[k]!=null){
				fl+=1;
			}
			}
		if(fl==0){
			$scope.brandCount=[];
			$scope.categoryCount=[];
			$scope.typeCount=[];
			$scope.sizeCount=[];
			for (i in $scope.allBrands){
				count=0;
				for(j in $scope.productList){
					if($scope.allBrands[i]==$scope.productList[j].brand){
						count+=1;
					}
				}
				$scope.brandCount.push(count);
			}
			for (i in $scope.allCategories){
				count=0;
				for(j in $scope.productList){
					temp = $scope.productList[j].name;
					temp = temp.split(" ");
					temp = temp[temp.length - 1];
					if($scope.allCategories[i]==temp){
						count+=1;
					}
				}
				$scope.categoryCount.push(count);
			}
			for (i in $scope.allTypes){
				count=0;
				for(j in $scope.productList){
					temp = $scope.productList[j].specification;
					temp = temp.split(";");
					temp = temp[1].split(":");
					if($scope.allTypes[i]==temp[1]){
						count+=1;
					}
				}
				$scope.typeCount.push(count);
			}
			
			for (i in $scope.allSizes){
				count=0;
				for(j in $scope.productList){
					temp = $scope.productList[j].specification;
					temp = temp.split(";");
					temp = temp[2].split(":");
					if($scope.allSizes[i]==temp[1]){
						count+=1;
					}
				}
				$scope.sizeCount.push(count);
			}
			return;
			
		}
		
		if($scope.brandButton){
			$scope.brandCount=[];
		for (i in $scope.brands){
			count=0;
			for(j in $scope.productList){
				if($scope.brands[i]==$scope.productList[j].brand){
					count+=1;
				}
			}
			$scope.brandCount.push(count);
		}}
		if($scope.categoryButton){
			$scope.categoryCount=[];
		for (i in $scope.categories){
			count=0;
			for(j in $scope.productList){
				temp = $scope.productList[j].name;
				temp = temp.split(" ");
				temp = temp[temp.length - 1];
				if($scope.categories[i]==temp){
					count+=1;
				}
			}
			$scope.categoryCount.push(count);
		}}
		if($scope.typeButton){
			$scope.typeCount=[];
		for (i in $scope.types){
			count=0;
			for(j in $scope.productList){
				temp = $scope.productList[j].specification;
				temp = temp.split(";");
				temp = temp[1].split(":");
				if($scope.types[i]==temp[1]){
					count+=1;
				}
			}
			$scope.typeCount.push(count);
		}
		}
		if($scope.sizeButton){
			$scope.sizeCount=[];
		for (i in $scope.sizes){
			count=0;
			for(j in $scope.productList){
				temp = $scope.productList[j].specification;
				temp = temp.split(";");
				temp = temp[2].split(":");
				if($scope.sizes[i]==temp[1]){
					count+=1;
				}
			}
			$scope.sizeCount.push(count);
		}
		
		}
	
		
	};

	$scope.logout = function() {

		$cookies.remove('userName');

		window.location = "../index.html";

	};

	
	
	
	// for list view and grid view
	
	$scope.gridview=true;
	$scope.listview=false;
	
	
	$scope.grid=function (){
		$scope.gridview=true;
		$scope.listview=false;
	};
	
	
	$scope.list=function (){
		$scope.gridview=false;
		$scope.listview=true;
	};
	
	
	$scope.productPage=function(item){
		$cookies.put("id",item.productId);
		$cookies.put("image",item.image);
		$cookies.put("name",item.name);
		$cookies.put("brand",item.brand);
		$cookies.put("quantity",item.quantity);
		$cookies.put("sellingPrice",item.sellingPrice);
		$cookies.put("discount",item.discount);
		$cookies.put("specification",item.specification);
		
		window.location="shop.html";
	};
	
	$scope.priceFilter=function(){
		tempList=[]
		for( i in $scope.productList){
			if($scope.productList[i].sellingPrice>=$scope.filter.minPrice && $scope.productList[i].sellingPrice<=$scope.filter.maxPrice)
				{
				tempList.push($scope.productList[i]);
				}
		}
		$scope.productList=tempList;
	};

});
