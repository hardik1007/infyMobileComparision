clothingApp.controller("LoginController", function($scope, $http,$cookies) {
	$scope.loginForm={};
	$scope.loginForm.userName=null;
	$scope.loginForm.password=null;
	$scope.loginForm.message=null;
	$scope.loginForm.submitTheForm= function(){
		
		$scope.loginForm.message = null;
		var data = JSON.stringify($scope.loginForm);
		
		$http.post(URI + "Clothing/login", data).then(function(response) {
			
			$cookies.put("userName",
					response.data.userName);
			$cookies.put("userId",
					response.data.userId);
			window.location="partials/clothingHome.html";
		}, function(response) {
			$scope.loginForm.message = response.data.message;
		});
		
	}


});

