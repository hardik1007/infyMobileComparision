package com.infy.clothing.resources;

import com.infy.clothing.business.service.ClothingsService;
import com.infy.clothing.business.service.ClothingsServiceImpl;
import com.infy.clothing.client.InfyRetailClient;

public class Factory{
	
	public static ClothingsService createClothService()
	{
		return new ClothingsServiceImpl();
	}
	public static InfyRetailClient createInfyRetailClient()
	{
		return new InfyRetailClient();
	}
	
}