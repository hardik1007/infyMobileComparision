package com.infy.clothing.resources;


@SuppressWarnings("all")
public class JSONParser {
	public static String toJson(Object obj) throws Exception {
		return new com.infy.jsonparrser.JSONParser().toJson(obj);
	}
	
	public static <T> T fromJson(String jsonInput, Class<T> classOfInputData)
			throws Exception {
		return new com.infy.jsonparrser.JSONParser().fromJson(jsonInput, classOfInputData);
	}
}
