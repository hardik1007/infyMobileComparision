package com.infy.clothing.api;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.infy.clothing.bean.LoginBean;
import com.infy.clothing.bean.Message;
import com.infy.clothing.bean.Product;
import com.infy.clothing.business.service.ClothingsService;
import com.infy.clothing.resources.AppConfig;
import com.infy.clothing.resources.Factory;
import com.infy.clothing.resources.JSONParser;

@Path("Clothing")
public class ClothingsAPI {
	@Path("login")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response login(String dataRecieved)
			throws Exception{
		
		Response response = null;
		LoginBean loginDetails= JSONParser.fromJson(dataRecieved, LoginBean.class);
		
		try {
			
			ClothingsService clothservice = Factory.createClothService();
/*			System.out.println("inside API");
			System.out.println(clothservice);*/
			LoginBean returnObj=clothservice.loginService(loginDetails);			
			String returnValue = JSONParser.toJson(returnObj);
			response = Response.status(Status.OK).entity(returnValue).build(); 
		} catch (Exception e) {
			String errorMessage = AppConfig.PROPERTIES.getProperty(e.getMessage());
			
			LoginBean bean = new LoginBean();
			bean.setMessage(errorMessage);
			
			String returnValue = JSONParser.toJson(bean);
			response = Response.status(Status.SERVICE_UNAVAILABLE)
					.entity(returnValue).build();
		}
		return response;
	}
	
	@GET
	@Path("allProductsList")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllProductsList() throws Exception {
		Response response = null;

		try {
			ClothingsService clothService = Factory.createClothService();
			List<Product> productList = clothService.getAllProducts();
			String returnString = JSONParser.toJson(productList);
			response = Response.ok(returnString).build();
		} catch (Exception e) {
			Product beanForMessage = new Product();  // message bean to be used
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			}
		}

		return response;
	}
	
	@Path("/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public static Response getAllSuggestedProducts(@PathParam("id") String id) throws Exception{
           
           Response response=null;
           String returnValue=null;
           try {
                 // System.out.println(id);
                  
                  ClothingsService service=Factory.createClothService();
                  returnValue=JSONParser.toJson(service.getAllSuggestedProducts(id));
                 // System.out.println(returnValue);
           
                  response=Response.status(Status.OK).entity(returnValue).build();
           
           } catch (Exception e) {
                  
                  Message message=new Message();
                  message.setMessage((e
                               .getMessage()));
                  String returnString = JSONParser.toJson(message);
                  
                  response = Response.status(Status.SERVICE_UNAVAILABLE).entity(returnString).build();
                  

                  
           }
           return response;
           
    }



}
