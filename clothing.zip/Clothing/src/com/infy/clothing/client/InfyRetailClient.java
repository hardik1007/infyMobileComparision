package com.infy.clothing.client;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.infy.clothing.bean.LoginBean;
import com.infy.clothing.bean.OrderProduct;
import com.infy.clothing.bean.Product;
import com.infy.clothing.resources.AppConfig;

public class InfyRetailClient{
	
	private static String infyRetailURL;
	static{
		infyRetailURL=AppConfig.PROPERTIES.getProperty("InfyRetailURL");
	}
	static Client client = javax.ws.rs.client.ClientBuilder.newClient();
	public LoginBean login(LoginBean loginDetails) throws Exception{
		
		Response response = client.target(infyRetailURL)
				.path("api")
				.path("LoginAPI")
				.request(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)
				.post(Entity.json(loginDetails),Response.class);
		if(response.getStatus()!=200){
			throw new Exception("CLIENT.INVALID_LOGIN");
		}
		return response.readEntity(LoginBean.class);
		
	}
	
	public List<Product> getAllProducts(){
		Response response = client.target(infyRetailURL)
				.path("api")
				.path("ProductAPI")
				.path("allProductsList")
				.request()
				.accept(MediaType.APPLICATION_JSON)
				.get();
		GenericType<List<Product>> result=new GenericType<List<Product>>(){};

		List<Product> newResutList=null;		
		if(response.getStatus()==200){
			newResutList=response.readEntity(result);
		}
		
		return newResutList;
		
	}
	
	public List<OrderProduct> getAllOrderProduct() throws Exception{
		Response response = client.target(infyRetailURL).path("api").path("OrderAPI").path("OrderProducts").request()
				.accept(MediaType.APPLICATION_JSON)
				.get();
		GenericType<List<OrderProduct>> result=new GenericType<List<OrderProduct>>(){};
		List<OrderProduct> newResutList=null;	
		if(response.getStatus()==200){
			newResutList=response.readEntity(result);
		}
		return newResutList;
	}
	
	
	
}
