package com.infy.clothing.business.service;

import java.util.List;

import com.infy.clothing.bean.LoginBean;
import com.infy.clothing.bean.Product;


public interface ClothingsService {

	public LoginBean loginService( LoginBean details) throws Exception;
	public List<Product> getAllProducts() throws Exception;
	public List<Product> getAllSuggestedProducts(String pId) throws Exception;
}
