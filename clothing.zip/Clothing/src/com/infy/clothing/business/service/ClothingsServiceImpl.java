package com.infy.clothing.business.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.infy.clothing.bean.LoginBean;
import com.infy.clothing.bean.OrderProduct;
import com.infy.clothing.client.InfyRetailClient;
import com.infy.clothing.resources.Factory;
import com.infy.clothing.bean.Product;

public class ClothingsServiceImpl  implements ClothingsService{
	
	public LoginBean loginService( LoginBean details) throws Exception {
		try{
		/*	System.out.println("helloo inside clothing service");
			System.out.println(details);*/
		InfyRetailClient client = Factory.createInfyRetailClient();
		 return client.login(details);
		}
		catch(Exception E){
			throw new Exception(E.getMessage());
		}
	}
	
	public List<Product> getAllProducts() throws Exception{
		try{
			InfyRetailClient client = Factory.createInfyRetailClient();
			return client.getAllProducts();
			
		}
		catch(Exception E){
			throw new Exception(E.getMessage());
		}
		
	}
	
	public List<Product> getAllSuggestedProducts(String pId) throws Exception{
        
        InfyRetailClient infyClient=new InfyRetailClient();
               List<OrderProduct> orderProducts=new ArrayList<>();
               List<OrderProduct> filteredOrderProducts=new ArrayList<>();
               List<Integer> filteredProductsId=new ArrayList<>();
               List<Product> productsFromMethod=new ArrayList<>();
               List<Product> suggestedProducts=new ArrayList<>();
               
               try{
                     orderProducts=infyClient.getAllOrderProduct();
                     for(OrderProduct p:orderProducts)
                     {
                            if(p.getProductId().toString().equalsIgnoreCase(pId))
                            {
                                   filteredOrderProducts.add(p);
                            }
                            
                     }
                
               
                     
                                                 
                     for(OrderProduct p1:orderProducts)
                     {
                            for(OrderProduct p2:filteredOrderProducts)
                            {
                            if(p1.getOrderId().toString().equals(p2.getOrderId().toString()) && p1.getProductId()!=p2.getProductId())
                            {
                            
                            filteredProductsId.add(p1.getProductId());
                     }
                            }
                     }
                     
                     System.out.println(filteredProductsId);
                     
                     for(Integer productId:filteredProductsId)
                     {
                            productsFromMethod=getAllProducts();
                            for(Product p:productsFromMethod)
                            {
                                   
                                   if(productId.equals(p.getProductId()))
                                   {
                                          suggestedProducts.add(p);
                                   }
                            }
                     }
                     
                     
               }catch(Exception e){
            	   e.printStackTrace();
                     Logger logger = Logger.getLogger(this.getClass());
                     logger.error(e.getMessage(), e);
                     throw e;
               }
               System.out.println(suggestedProducts);
               return suggestedProducts;
        };

}
